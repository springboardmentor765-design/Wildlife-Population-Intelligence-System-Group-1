import { useEffect, useRef, useState } from 'react';
import { AudioLines, Pause, Play, RotateCcw } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { FileUpload } from '../components/ui/FileUpload';
import { Waveform } from '../components/ui/Waveform';
import { Button } from '../components/ui/Button';
import { Badge, IucnBadge, StatusBadge } from '../components/ui/Badge';
import { Skeleton, SkeletonCards } from '../components/ui/Skeleton';
import { EmptyState, ErrorState } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { audioService } from '../services/audioService';
import { confidenceTone, formatDateTime, formatDuration } from '../utils/format';

export default function Bioacoustics() {
  const { data: recordings, loading, error, reload } = useAsync(() => audioService.list(), []);
  const [activeId, setActiveId] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const timer = useRef(null);

  const active = recordings?.find((r) => r.id === activeId) ?? recordings?.[0] ?? null;

  useEffect(() => {
    if (!playing || !active) return undefined;
    timer.current = setInterval(() => {
      setPosition((p) => {
        if (p >= active.duration) {
          setPlaying(false);
          return 0;
        }
        return p + 0.5;
      });
    }, 250);
    return () => clearInterval(timer.current);
  }, [playing, active]);

  const upload = async (files) => {
    setUploading(true);
    setProgress(0);
    try {
      await audioService.upload(files, { onProgress: setProgress });
      reload();
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const currentDetection = active?.detections.find((d) => position >= d.start && position <= d.end);

  return (
    <>
      <PageHeader
        eyebrow="Field data"
        title="Bioacoustics"
        description="Recordings are denoised, then matched against bird, mammal and amphibian call models."
      />

      <div className="grid gap-6 xl:grid-cols-[340px_1fr]">
        <div className="space-y-6">
          <Card>
            <CardHeader eyebrow="Ingest" title="Upload recordings" />
            <CardBody>
              <FileUpload
                accept="audio/*"
                label="Drop audio recordings here"
                hint="WAV or FLAC, 44.1–48 kHz"
                onUpload={upload}
                uploading={uploading}
                progress={progress}
              />
            </CardBody>
          </Card>

          <Card>
            <CardHeader eyebrow="Library" title="Recordings" />
            <div className="max-h-[440px] overflow-y-auto">
              {loading && (
                <div className="space-y-3 p-4">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16" />)}
                </div>
              )}
              {!loading && recordings?.map((r) => (
                <button
                  key={r.id}
                  onClick={() => { setActiveId(r.id); setPosition(0); setPlaying(false); }}
                  className={`block w-full border-b border-sand-100 px-4 py-3.5 text-left transition last:border-0 ${
                    active?.id === r.id ? 'bg-moss-50' : 'hover:bg-sand-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="truncate font-mono text-[12px] font-medium text-ink-900">{r.filename}</p>
                    <StatusBadge status={r.status} />
                  </div>
                  <p className="mt-1 text-[12px] text-ink-500">
                    {formatDateTime(r.recordedAt)} · {formatDuration(r.duration)} · {r.detections.length} call{r.detections.length === 1 ? '' : 's'}
                  </p>
                </button>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          {loading && <SkeletonCards count={2} height="h-64" />}
          {error && !loading && <ErrorState message={error} onRetry={reload} />}

          {!loading && !error && !active && (
            <Card>
              <EmptyState
                icon={AudioLines}
                title="No recordings in the library"
                message="Upload a WAV file from an acoustic sensor to run call detection."
              />
            </Card>
          )}

          {!loading && !error && active && (
            <>
              <Card>
                <CardHeader
                  eyebrow={active.site}
                  title={active.filename}
                  description={`${active.sampleRate} · ${active.channels} · noise floor ${active.noiseFloor} dB`}
                  action={
                    <Badge tone={active.noiseFiltered ? 'moss' : 'warn'}>
                      {active.noiseFiltered ? 'Noise filtered' : 'Raw audio'}
                    </Badge>
                  }
                />
                <CardBody>
                  <Waveform
                    data={active.waveform}
                    duration={active.duration}
                    position={position}
                    detections={active.detections}
                    activeId={currentDetection?.id}
                    onSeek={(t) => setPosition(Math.max(0, Math.min(active.duration, t)))}
                  />

                  <div className="mt-4 flex items-center gap-3">
                    <Button
                      icon={playing ? Pause : Play}
                      onClick={() => setPlaying((p) => !p)}
                    >
                      {playing ? 'Pause' : 'Play'}
                    </Button>
                    <Button variant="ghost" icon={RotateCcw} onClick={() => { setPosition(0); setPlaying(false); }}>
                      Restart
                    </Button>
                    <span className="ml-auto font-mono text-sm text-ink-700 tabular-nums">
                      {formatDuration(position)} / {formatDuration(active.duration)}
                    </span>
                  </div>

                  {currentDetection && (
                    <p className="mt-3 rounded-lg bg-moss-50 px-3.5 py-2.5 text-sm text-moss-700">
                      Now playing over a detection: <strong>{currentDetection.species}</strong>
                    </p>
                  )}
                </CardBody>
              </Card>

              <Card>
                <CardHeader eyebrow="Model output" title="Detected calls" description="Click a row to jump to that moment in the recording." />
                {active.detections.length === 0 ? (
                  <EmptyState
                    icon={AudioLines}
                    title="Still processing"
                    message="Call detection finishes within a few minutes of upload. Check back shortly."
                  />
                ) : (
                  <ul className="divide-y divide-sand-100">
                    {active.detections.map((d) => (
                      <li key={d.id}>
                        <button
                          onClick={() => setPosition(d.start)}
                          className="flex w-full items-center gap-4 px-5 py-4 text-left hover:bg-sand-50"
                        >
                          <span className="font-mono text-[12px] text-ink-500 tabular-nums w-14 shrink-0">
                            {formatDuration(d.start)}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-medium text-ink-900">{d.species}</p>
                            {d.binomial && <p className="binomial truncate text-[12px]">{d.binomial}</p>}
                          </div>
                          <Badge className="hidden sm:inline-flex">{d.type}</Badge>
                          {d.iucn && <IucnBadge code={d.iucn} showLabel={false} />}
                          <span className={`font-mono text-sm shrink-0 ${confidenceTone(d.confidence)}`}>
                            {Math.round(d.confidence * 100)}%
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            </>
          )}
        </div>
      </div>
    </>
  );
}

import api, { USE_MOCK } from './api';
import { mockImages } from '../mock/images';
import { respond, delay } from '../mock/_helpers';

export const imageService = {
  async list(params = {}) {
    if (USE_MOCK) {
      let rows = [...mockImages];
      if (params.siteId) rows = rows.filter((i) => i.siteId === params.siteId);
      if (params.species) {
        rows = rows.filter((i) => i.boxes.some((b) => b.common === params.species));
      }
      return respond(rows, 650);
    }
    const { data } = await api.get('/images', { params });
    return data;
  },

  async get(id) {
    if (USE_MOCK) return respond(mockImages.find((i) => i.id === id) || null);
    const { data } = await api.get(`/images/${id}`);
    return data;
  },

  // Upload + run detection. onProgress receives 0–100.
  async upload(files, { siteId, onProgress } = {}) {
    if (USE_MOCK) {
      for (let p = 10; p <= 100; p += 15) {
        await delay(160);
        onProgress?.(Math.min(p, 100));
      }
      return respond(
        files.map((f, idx) => ({
          ...mockImages[idx % mockImages.length],
          id: `img-${Math.random().toString(36).slice(2, 7)}`,
          filename: f.name,
          siteId: siteId || 'site-01',
          status: 'analyzed',
        })),
        500
      );
    }
    const form = new FormData();
    files.forEach((f) => form.append('files', f));
    if (siteId) form.append('site_id', siteId);
    const { data } = await api.post('/images/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => onProgress?.(Math.round((e.loaded * 100) / (e.total || 1))),
    });
    return data;
  },
};

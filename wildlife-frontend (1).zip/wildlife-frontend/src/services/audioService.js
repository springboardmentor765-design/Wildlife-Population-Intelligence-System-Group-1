import api, { USE_MOCK } from './api';
import { mockRecordings } from '../mock/audio';
import { respond, delay } from '../mock/_helpers';

export const audioService = {
  async list(params = {}) {
    if (USE_MOCK) return respond(mockRecordings, 600);
    const { data } = await api.get('/bioacoustics/recordings', { params });
    return data;
  },

  async get(id) {
    if (USE_MOCK) return respond(mockRecordings.find((r) => r.id === id) || null);
    const { data } = await api.get(`/bioacoustics/recordings/${id}`);
    return data;
  },

  async upload(files, { siteId, onProgress } = {}) {
    if (USE_MOCK) {
      for (let p = 12; p <= 100; p += 12) {
        await delay(180);
        onProgress?.(Math.min(p, 100));
      }
      return respond(
        files.map((f, i) => ({
          ...mockRecordings[i % mockRecordings.length],
          id: `aud-${Math.random().toString(36).slice(2, 7)}`,
          filename: f.name,
          siteId: siteId || 'site-02',
          status: 'analyzed',
        })),
        400
      );
    }
    const form = new FormData();
    files.forEach((f) => form.append('files', f));
    if (siteId) form.append('site_id', siteId);
    const { data } = await api.post('/bioacoustics/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => onProgress?.(Math.round((e.loaded * 100) / (e.total || 1))),
    });
    return data;
  },
};

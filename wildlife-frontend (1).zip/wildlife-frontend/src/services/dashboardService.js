import api, { USE_MOCK } from './api';
import { researcherSummary, conservationSummary, forestSummary } from '../mock/dashboards';
import { respond } from '../mock/_helpers';
import { ROLES } from '../utils/constants';

const byRole = {
  [ROLES.RESEARCHER]: researcherSummary,
  [ROLES.CONSERVATION]: conservationSummary,
  [ROLES.FOREST]: forestSummary,
};

export const dashboardService = {
  async summary(role) {
    if (USE_MOCK) return respond(byRole[role] ?? researcherSummary, 700);
    const { data } = await api.get('/dashboard', { params: { role } });
    return data;
  },
};

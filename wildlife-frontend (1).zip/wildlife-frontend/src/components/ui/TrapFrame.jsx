import { clsx } from '../../utils/cn';
import { IUCN } from '../../utils/constants';

/**
 * Camera-trap frame renderer.
 *
 * Real deployments serve a JPEG from `image.url`; until the API is connected we
 * draw a synthetic frame in the same 4:3 geometry so bounding-box coordinates,
 * the IR/daylight treatment and the burnt-in timestamp strip all behave exactly
 * as they will against real captures.
 */

const PALETTES = {
  infrared: { sky: '#0E1512', mid: '#1A241E', ground: '#232E27', flora: '#2E3A32', subject: '#4A574D', haze: '#3A463D' },
  daylight: { sky: '#8FA88C', mid: '#5E7A57', ground: '#6B7A4E', flora: '#3F5A3B', subject: '#4B5A3F', haze: '#A8BC9E' },
};

const SCENES = {
  trail: [[0, 68], [18, 62], [34, 66], [52, 60], [70, 65], [86, 61], [100, 66]],
  clearing: [[0, 72], [22, 70], [46, 74], [68, 70], [100, 73]],
  water: [[0, 66], [25, 64], [50, 67], [75, 63], [100, 66]],
  canopy: [[0, 82], [30, 80], [60, 84], [100, 81]],
  grassland: [[0, 70], [20, 67], [45, 71], [72, 68], [100, 70]],
};

export function TrapFrame({ image, showBoxes = true, activeBox = null, className = '' }) {
  const p = PALETTES[image.mode] ?? PALETTES.infrared;
  const horizon = (SCENES[image.scene] ?? SCENES.trail)[0][1];
  const ridge = (SCENES[image.scene] ?? SCENES.trail)
    .map(([x, y]) => `${x},${y}`)
    .join(' ');

  return (
    <div className={clsx('relative w-full overflow-hidden rounded-xl bg-canopy-950', className)}>
      <svg viewBox="0 0 100 75" className="block w-full h-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id={`sky-${image.id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={p.sky} />
            <stop offset="100%" stopColor={p.haze} stopOpacity="0.5" />
          </linearGradient>
          <radialGradient id={`vig-${image.id}`} cx="50%" cy="45%" r="72%">
            <stop offset="55%" stopColor="#000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000" stopOpacity="0.55" />
          </radialGradient>
        </defs>

        <rect width="100" height="75" fill={`url(#sky-${image.id})`} />
        <polygon points={`0,75 100,75 ${ridge.split(' ').reverse().join(' ')}`} fill={p.mid} />
        <rect y={horizon + 4} width="100" height={75 - horizon} fill={p.ground} />

        {/* Vegetation silhouettes — density varies by scene */}
        {[8, 24, 41, 59, 76, 92].map((x, i) => (
          <g key={x} opacity={image.scene === 'canopy' ? 0.9 : 0.65}>
            <rect x={x} y={horizon - 16 - (i % 3) * 5} width="1.2" height={20 + (i % 3) * 5} fill={p.flora} />
            <ellipse cx={x + 0.6} cy={horizon - 18 - (i % 3) * 5} rx={5 + (i % 4)} ry={4 + (i % 3)} fill={p.flora} />
          </g>
        ))}

        {image.scene === 'water' && (
          <rect y={horizon + 10} width="100" height={75 - horizon - 10} fill={p.haze} opacity="0.35" />
        )}

        {/* Subject mass under each detection so boxes sit on something */}
        {image.boxes?.map((b, i) => (
          <ellipse
            key={i}
            cx={b.x + b.w / 2}
            cy={(b.y + b.h / 2) * 0.75}
            rx={(b.w / 2) * 0.8}
            ry={((b.h / 2) * 0.75) * 0.8}
            fill={p.subject}
            opacity="0.9"
          />
        ))}

        <rect width="100" height="75" fill={`url(#vig-${image.id})`} />
        {image.mode === 'infrared' && (
          <rect width="100" height="75" fill="#7FA8B8" opacity="0.06" />
        )}
      </svg>

      {/* Burnt-in camera strip, as trap firmware writes it */}
      <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-black/55 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wide text-white/85">
        <span className="truncate">{image.filename}</span>
        <span className="shrink-0">
          {image.mode === 'infrared' ? 'IR' : 'DAY'} · {image.temperature}
        </span>
      </div>

      {showBoxes &&
        image.boxes?.map((b, i) => {
          const c = IUCN[b.iucn];
          const stroke = c ? { LC: '#60C659', NT: '#CCE226', VU: '#F9E814', EN: '#FC7F3F', CR: '#D81E05' }[b.iucn] : '#9CA3AF';
          const dim = activeBox !== null && activeBox !== i;
          return (
            <div
              key={i}
              className={clsx('absolute transition-opacity duration-200', dim ? 'opacity-25' : 'opacity-100')}
              style={{ left: `${b.x}%`, top: `${b.y}%`, width: `${b.w}%`, height: `${b.h}%` }}
            >
              <div
                className="absolute inset-0 rounded-[3px] border-2"
                style={{ borderColor: stroke, boxShadow: `0 0 0 1px rgba(0,0,0,0.35)` }}
              />
              <span
                className="absolute -top-[19px] left-0 whitespace-nowrap rounded-[3px] px-1.5 py-0.5 font-mono text-[10px] font-medium text-canopy-950"
                style={{ backgroundColor: stroke }}
              >
                {b.common} {Math.round(b.confidence * 100)}%
              </span>
            </div>
          );
        })}
    </div>
  );
}
